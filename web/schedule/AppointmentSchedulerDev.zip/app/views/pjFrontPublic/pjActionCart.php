<div class="asBox asServicesOuter">
	<div class="asServicesInner">
		<div class="asHeading"><?php __('front_selected_services'); ?></div>
		<div class="asSelectorElements asOverflowHidden">
		<?php include PJ_VIEWS_PATH . 'pjFrontEnd/pjActionGetCart.php'; ?>
		</div>
	</div>
</div>