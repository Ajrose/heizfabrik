<?php
echo nl2br(pjSanitize::html(@$tpl['terms_arr']['terms_body']));
?>