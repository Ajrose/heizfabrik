<?php

return [
    'Cart' => 'Carrello',
    'Checkout' => 'Procedi all\'acquisto',
    'Remove' => 'Rimuovi',
    'View Cart' => 'Visualizza il carrello',
    'You have no items in your shopping cart.' => 'Non hai nessun prodotto nel tuo carrello.',
];
