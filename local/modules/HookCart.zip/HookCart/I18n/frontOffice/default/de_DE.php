<?php

return [
    'Cart' => 'Warenkorb',
    'Checkout' => 'Zur Kasse',
    'Remove' => 'Entfernen',
    'View Cart' => 'Warenkorb anzeigen',
    'You have no items in your shopping cart.' => 'Sie haben keine Produkte im Warenkorb',
];
