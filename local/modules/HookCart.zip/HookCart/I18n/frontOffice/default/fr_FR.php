<?php

return [
    'Cart' => 'Panier',
    'Checkout' => 'Commande',
    'Remove' => 'Supprimer',
    'View Cart' => 'Voir le panier',
    'You have no items in your shopping cart.' => 'Vous n\'avez pas de produit dans votre panier.',
];
