<?php

return array(
    'Cart' => 'Cart',
    'Checkout' => 'Checkout',
    'Remove' => 'Remove',
    'View Cart' => 'View Cart',
    'You have no items in your shopping cart.' => 'You have no items in your shopping cart.',
);
