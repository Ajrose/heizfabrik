<?php

return [
    'Cart' => 'Sepet',
    'Checkout' => 'Ödeme  yap',
    'Remove' => 'Kaldır',
    'View Cart' => 'Sepeti Görüntüle',
    'You have no items in your shopping cart.' => 'Sepetinizde hiç ürün yok.',
];
