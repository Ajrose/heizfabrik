<?php
namespace HookKonfigurator\Import;

use Thelia\Core\FileFormat\Formatting\FormatterData;
use Thelia\Core\FileFormat\FormatType;
use Thelia\ImportExport\Import\ImportHandler;
use Thelia\Model\ProductSaleElementsQuery;
use Thelia\Log\Tlog;
use Thelia\Model\ProductQuery;
use HookKonfigurator\Model\ConstraintsQuery;
use Thelia\Model\ProductI18n;
use Thelia\Model\Product;
use HookKonfigurator\Model\Montage;
use HookKonfigurator\Model\MontageConstraints;
use HookKonfigurator\Model\Constraints;
use Thelia\Model\ProductImage;

/**
 * Class SanitaryImport
 * @package HookKonfigurator\Import
 * @author Emanuel Plopu <emanuel.plopu@sepa.at>
 */
class UpdateProduct extends ImportHandler
{
	
    /**
     * @param \Thelia\Core\FileFormat\Formatting\FormatterData
     * @return string|array error messages
     *
     * The method does the import routine from a FormatterData
     */
    public function retrieveFromFormatterData(FormatterData $data)
    {
        $errors = [];
        $log = Tlog::getInstance ();
        $log->debug(" update_importer ");

        $productQuerry = ProductQuery::create ();

        $currentDate = date ( "Y-m-d H:i:s" );

        $i= 0;
        while (null !== $row = $data->popRow()) {

        	$log->debug(" update_product ".$i.implode(" ",$row));
            $this->checkMandatoryColumns($row);
            
            $gc_id     = $row["gc_id"];
          //  $extern_id = $row["extern_id"];
            
           // HookScraperController
            
            $errors[$i]= $gc_id.$currentDate ;
            
        	$i++;
        }

        return $errors;
    }

    protected function getMandatoryColumns()
    {
        return ["extern_id"];
    }

    /**
     * @return string|array
     *
     * Define all the type of import/formatters that this can handle
     * return a string if it handle a single type ( specific exports ),
     * or an array if multiple.
     *
     * Thelia types are defined in \Thelia\Core\FileFormat\FormatType
     *
     * example:
     * return array(
     *     FormatType::TABLE,
     *     FormatType::UNBOUNDED,
     * );
     */
    public function getHandledTypes()
    {
        return array(
            FormatType::TABLE,
            FormatType::UNBOUNDED,
        );
    }
}
