<?php

return array(
	'buildingtype' => 'Building type',
);
