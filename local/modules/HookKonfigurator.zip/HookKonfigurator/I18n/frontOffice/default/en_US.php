<?php

return array(
	'Configurator' => 'Configurator',
	'buildingtype' => 'Building Type',
	'Your personal offer' => 'Your personal offer',
		'Here you can configure your heating system' => 'Here you can configure your heating system',
);
