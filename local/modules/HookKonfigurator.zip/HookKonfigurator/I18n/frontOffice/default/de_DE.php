<?php

return array(
    'Configurator' => 'Konfigurator',
	'buildingtype' => 'Geb&auml;udeart',
	'Your personal offer' => 'Ihr pers&ouml;nliches Angebot',
	'Here you can configure your heating system' => 'Konfigurieren Sie hier Ihre Heizung',
	'Grade' => 'Klasse',
	'Power' => 'Wärmenennleistung',
	'Warmwater' => 'Warmwasser',
	'Add to cart' => 'In den Warenkorb',
);
