<?php
return array(
    'buildingtype' => 'B&acirc;timent',
	'Configurator' => 'Configurateur',
	'Your personal offer' => 'Votre offre personnelle',
	'Here you can configure your heating system' => 'Ici, vous pouvez configurer votre syst&eacute;me de chauffage',
);
