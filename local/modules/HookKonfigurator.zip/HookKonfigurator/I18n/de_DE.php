<?php

return array(
    'buildingtype' => 'Geb�udeart',

);
