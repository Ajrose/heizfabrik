<?php
namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\SetMontageQuery as BaseSetMontageQuery;


/**
 * Skeleton subclass for performing query and update operations on the 'set_montage' table.
 *
 * 
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 *
 */
class SetMontageQuery extends BaseSetMontageQuery
{

} // SetMontageQuery
