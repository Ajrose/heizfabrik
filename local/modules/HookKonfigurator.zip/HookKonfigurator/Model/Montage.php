<?php

use Base\Montage as BaseMontage;

class Montage extends BaseMontage
{

}
