<?php
namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\ProductHeizungMontage as BaseProductHeizungMontage;

class ProductHeizungMontage extends BaseProductHeizungMontage
{

}
