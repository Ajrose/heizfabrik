<?php
namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\Sets as BaseSets;

class Sets extends BaseSets
{

}
