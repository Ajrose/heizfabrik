<?php
namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\SetMontage as BaseSetMontage;

class SetMontage extends BaseSetMontage
{

}
