<?php

namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\HeizungkonfiguratorImage as BaseHeizungkonfiguratorImage;

class HeizungkonfiguratorImage extends BaseHeizungkonfiguratorImage
{

}
