<?php

namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\HeizungkonfiguratorUserdaten as BaseHeizungkonfiguratorUserdaten;

class HeizungkonfiguratorUserdaten extends BaseHeizungkonfiguratorUserdaten
{

}
