<?php

namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\Constraints as BaseConstraints;

class Constraints extends BaseConstraints
{

}
