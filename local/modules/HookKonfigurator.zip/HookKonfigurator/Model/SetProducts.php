<?php

use Base\SetProducts as BaseSetProducts;

class SetProducts extends BaseSetProducts
{

}
