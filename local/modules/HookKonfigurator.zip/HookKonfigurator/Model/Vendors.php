<?php
namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\Vendors as BaseVendors;

class Vendors extends BaseVendors
{

}
