<?php
namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\ProductHeizung as BaseProductHeizung;

class ProductHeizung extends BaseProductHeizung
{

}
