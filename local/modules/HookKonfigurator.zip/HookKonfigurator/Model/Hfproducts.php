<?php
namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\Hfproducts as BaseHfproducts;

class Hfproducts extends BaseHfproducts
{

}
