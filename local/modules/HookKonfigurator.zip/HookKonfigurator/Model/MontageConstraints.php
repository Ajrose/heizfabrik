<?php
namespace HookKonfigurator\Model;

use HookKonfigurator\Model\Base\MontageConstraints as BaseMontageConstraints;

class MontageConstraints extends BaseMontageConstraints
{

}
